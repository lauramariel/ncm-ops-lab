#!/bin/bash
set -ex

PC_IP="$1"
# Update sizer timeout and restart sizer
# https://jira.nutanix.com/browse/ENG-430580


# Add DCBC_TIMEOUT_MS=1000 flag to the java call in sizer_service.sh
# then kill sizer and restart neuron service
ssh nutanix@$PC_IP "source /etc/profile
sed -i '/-DCBC_PATH*/a \  -DCBC_TIMEOUT_MS=1000 \\\' /home/nutanix/neuron/bin/sizer_service.sh
ps aux | grep sizer | grep java | grep -v grep | awk '{print \$2}' > /home/nutanix/pid.txt
sleep 5
kill -9 \$(cat /home/nutanix/pid.txt)
sleep 5
genesis stop neuron
cluster start"

# ps aux | grep sizer | grep java | awk '{print $2}'
