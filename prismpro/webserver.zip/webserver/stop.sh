pm2 stop prismpro-webserver; pm2 delete prismpro-webserver; pm2 save --force;
